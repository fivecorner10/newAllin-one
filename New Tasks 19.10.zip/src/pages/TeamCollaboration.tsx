import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface Message {
  id: number;
  sender: string;
  content: string;
  timestamp: string;
}

const TeamCollaboration: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, sender: 'John Doe', content: 'Hey team, how\'s the project coming along?', timestamp: '10:30 AM' },
    { id: 2, sender: 'Jane Smith', content: 'We\'re making good progress. I\'ve just finished the design mockups.', timestamp: '10:35 AM' },
  ]);

  const [newMessage, setNewMessage] = useState('');

  const sendMessage = () => {
    if (newMessage) {
      setMessages([...messages, {
        id: messages.length + 1,
        sender: 'You',
        content: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setNewMessage('');
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Team Collaboration</h1>
      <div className="bg-white rounded-lg shadow-md h-[calc(100vh-200px)] flex flex-col">
        <div className="flex-grow overflow-y-auto p-4">
          {messages.map((message) => (
            <div key={message.id} className={`mb-4 ${message.sender === 'You' ? 'text-right' : ''}`}>
              <div className={`inline-block p-2 rounded-lg ${message.sender === 'You' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>
                <p className="font-semibold">{message.sender}</p>
                <p>{message.content}</p>
                <p className="text-xs mt-1 opacity-75">{message.timestamp}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="border-t p-4">
          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="Type your message..."
              className="flex-grow p-2 border rounded"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            />
            <button
              className="bg-blue-500 text-white p-2 rounded flex items-center"
              onClick={sendMessage}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamCollaboration;