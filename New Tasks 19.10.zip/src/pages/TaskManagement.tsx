import React, { useState } from 'react';
import { Plus, Edit2, Trash2 } from 'lucide-react';

interface Task {
  id: number;
  title: string;
  priority: 'low' | 'medium' | 'high';
  assignee: string;
  status: string;
}

const TaskManagement: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, title: 'Complete project proposal', priority: 'high', assignee: 'John Doe', status: 'In Progress' },
    { id: 2, title: 'Review client feedback', priority: 'medium', assignee: 'Jane Smith', status: 'Pending' },
  ]);

  const [newTask, setNewTask] = useState<Omit<Task, 'id'>>({ title: '', priority: 'medium', assignee: '', status: 'Pending' });

  const addTask = () => {
    if (newTask.title) {
      setTasks([...tasks, { ...newTask, id: tasks.length + 1 }]);
      setNewTask({ title: '', priority: 'medium', assignee: '', status: 'Pending' });
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Task Management</h1>
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Add New Task</h2>
        <div className="flex space-x-2">
          <input
            type="text"
            placeholder="Task title"
            className="flex-grow p-2 border rounded"
            value={newTask.title}
            onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
          />
          <select
            className="p-2 border rounded"
            value={newTask.priority}
            onChange={(e) => setNewTask({ ...newTask, priority: e.target.value as 'low' | 'medium' | 'high' })}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="text"
            placeholder="Assignee"
            className="p-2 border rounded"
            value={newTask.assignee}
            onChange={(e) => setNewTask({ ...newTask, assignee: e.target.value })}
          />
          <button
            className="bg-blue-500 text-white p-2 rounded flex items-center"
            onClick={addTask}
          >
            <Plus size={20} className="mr-1" /> Add Task
          </button>
        </div>
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-2">Task List</h2>
        <table className="w-full">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 text-left">Title</th>
              <th className="p-2 text-left">Priority</th>
              <th className="p-2 text-left">Assignee</th>
              <th className="p-2 text-left">Status</th>
              <th className="p-2 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task) => (
              <tr key={task.id} className="border-b">
                <td className="p-2">{task.title}</td>
                <td className="p-2">
                  <span className={`px-2 py-1 rounded text-sm ${
                    task.priority === 'high' ? 'bg-red-200 text-red-800' :
                    task.priority === 'medium' ? 'bg-yellow-200 text-yellow-800' :
                    'bg-green-200 text-green-800'
                  }`}>
                    {task.priority}
                  </span>
                </td>
                <td className="p-2">{task.assignee}</td>
                <td className="p-2">{task.status}</td>
                <td className="p-2">
                  <button className="text-blue-500 mr-2"><Edit2 size={18} /></button>
                  <button className="text-red-500"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TaskManagement;