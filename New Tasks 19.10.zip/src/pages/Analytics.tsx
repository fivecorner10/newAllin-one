import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface PerformanceData {
  name: string;
  tasks: number;
  timeTracked: number;
  habitsCompleted: number;
}

const Analytics: React.FC = () => {
  const data: PerformanceData[] = [
    { name: 'Mon', tasks: 4, timeTracked: 6, habitsCompleted: 3 },
    { name: 'Tue', tasks: 3, timeTracked: 5, habitsCompleted: 2 },
    { name: 'Wed', tasks: 5, timeTracked: 7, habitsCompleted: 4 },
    { name: 'Thu', tasks: 2, timeTracked: 4, habitsCompleted: 3 },
    { name: 'Fri', tasks: 6, timeTracked: 8, habitsCompleted: 5 },
    { name: 'Sat', tasks: 1, timeTracked: 3, habitsCompleted: 2 },
    { name: 'Sun', tasks: 2, timeTracked: 4, habitsCompleted: 1 },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Analytics</h1>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Weekly Performance</h2>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="tasks" fill="#8884d8" name="Tasks Completed" />
            <Bar dataKey="timeTracked" fill="#82ca9d" name="Hours Tracked" />
            <Bar dataKey="habitsCompleted" fill="#ffc658" name="Habits Completed" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Analytics;