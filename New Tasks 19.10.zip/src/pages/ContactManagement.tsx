import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Star } from 'lucide-react';

interface Contact {
  id: number;
  name: string;
  email: string;
  phone: string;
  score: number;
}

const ContactManagement: React.FC = () => {
  const [contacts, setContacts] = useState<Contact[]>([
    { id: 1, name: 'John Doe', email: 'john@example.com', phone: '123-456-7890', score: 8 },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '987-654-3210', score: 6 },
  ]);

  const [newContact, setNewContact] = useState<Omit<Contact, 'id' | 'score'>>({ name: '', email: '', phone: '' });

  const addContact = () => {
    if (newContact.name && newContact.email) {
      setContacts([...contacts, { ...newContact, id: contacts.length + 1, score: 5 }]);
      setNewContact({ name: '', email: '', phone: '' });
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Contact Management</h1>
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Add New Contact</h2>
        <div className="flex space-x-2">
          <input
            type="text"
            placeholder="Name"
            className="flex-grow p-2 border rounded"
            value={newContact.name}
            onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
          />
          <input
            type="email"
            placeholder="Email"
            className="flex-grow p-2 border rounded"
            value={newContact.email}
            onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
          />
          <input
            type="tel"
            placeholder="Phone"
            className="flex-grow p-2 border rounded"
            value={newContact.phone}
            onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
          />
          <button
            className="bg-blue-500 text-white p-2 rounded flex items-center"
            onClick={addContact}
          >
            <Plus size={20} className="mr-1" /> Add Contact
          </button>
        </div>
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-2">Contact List</h2>
        <table className="w-full">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 text-left">Name</th>
              <th className="p-2 text-left">Email</th>
              <th className="p-2 text-left">Phone</th>
              <th className="p-2 text-left">Score</th>
              <th className="p-2 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {contacts.map((contact) => (
              <tr key={contact.id} className="border-b">
                <td className="p-2">{contact.name}</td>
                <td className="p-2">{contact.email}</td>
                <td className="p-2">{contact.phone}</td>
                <td className="p-2">
                  <div className="flex items-center">
                    <span className="mr-2">{contact.score}</span>
                    <Star size={18} className={contact.score >= 7 ? 'text-yellow-400 fill-current' : 'text-gray-300'} />
                  </div>
                </td>
                <td className="p-2">
                  <button className="text-blue-500 mr-2"><Edit2 size={18} /></button>
                  <button className="text-red-500"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ContactManagement;