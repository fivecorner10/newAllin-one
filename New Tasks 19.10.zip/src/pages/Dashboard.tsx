import React from 'react';
import { CheckSquare, Users, Clock, Activity } from 'lucide-react';

interface DashboardCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ icon, title, value }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-4">
        <div className="text-gray-500">{icon}</div>
        <div className="text-2xl font-bold">{value}</div>
      </div>
      <div className="text-sm text-gray-500">{title}</div>
    </div>
  );
};

const Dashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard icon={<CheckSquare size={24} />} title="Tasks" value="5" />
        <DashboardCard icon={<Users size={24} />} title="Contacts" value="25" />
        <DashboardCard icon={<Clock size={24} />} title="Hours Tracked" value="32" />
        <DashboardCard icon={<Activity size={24} />} title="Habits Completed" value="3" />
      </div>
    </div>
  );
};

export default Dashboard;