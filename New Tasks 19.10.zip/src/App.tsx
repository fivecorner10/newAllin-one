import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import TaskManagement from './pages/TaskManagement';
import ContactManagement from './pages/ContactManagement';
import TimeTracking from './pages/TimeTracking';
import HabitTracking from './pages/HabitTracking';
import Analytics from './pages/Analytics';
import TeamCollaboration from './pages/TeamCollaboration';

function App() {
  return (
    <Router>
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <div className="flex-1 overflow-x-hidden overflow-y-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/tasks" element={<TaskManagement />} />
            <Route path="/contacts" element={<ContactManagement />} />
            <Route path="/time-tracking" element={<TimeTracking />} />
            <Route path="/habits" element={<HabitTracking />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/team" element={<TeamCollaboration />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;