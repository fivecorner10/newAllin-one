import React, { useState } from 'react';
import { Plus, Check, X } from 'lucide-react';

interface Habit {
  id: number;
  name: string;
  completed: boolean;
}

const HabitTracking: React.FC = () => {
  const [habits, setHabits] = useState<Habit[]>([
    { id: 1, name: 'Morning Meditation', completed: false },
    { id: 2, name: 'Read for 30 minutes', completed: true },
    { id: 3, name: 'Exercise', completed: false },
  ]);

  const [newHabit, setNewHabit] = useState('');

  const addHabit = () => {
    if (newHabit) {
      setHabits([...habits, { id: habits.length + 1, name: newHabit, completed: false }]);
      setNewHabit('');
    }
  };

  const toggleHabit = (id: number) => {
    setHabits(habits.map(habit =>
      habit.id === id ? { ...habit, completed: !habit.completed } : habit
    ));
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Habit Tracking</h1>
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Add New Habit</h2>
        <div className="flex space-x-2">
          <input
            type="text"
            placeholder="New habit"
            className="flex-grow p-2 border rounded"
            value={newHabit}
            onChange={(e) => setNewHabit(e.target.value)}
          />
          <button
            className="bg-blue-500 text-white p-2 rounded flex items-center"
            onClick={addHabit}
          >
            <Plus size={20} className="mr-1" /> Add Habit
          </button>
        </div>
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-2">Your Habits</h2>
        <ul className="space-y-2">
          {habits.map((habit) => (
            <li key={habit.id} className="flex items-center justify-between bg-white p-4 rounded-lg shadow">
              <span className={habit.completed ? 'line-through text-gray-500' : ''}>{habit.name}</span>
              <button
                className={`p-2 rounded-full ${habit.completed ? 'bg-green-500' : 'bg-gray-300'} text-white`}
                onClick={() => toggleHabit(habit.id)}
              >
                {habit.completed ? <Check size={20} /> : <X size={20} />}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default HabitTracking;