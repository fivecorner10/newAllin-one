import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const TimeTracking: React.FC = () => {
  const [isTracking, setIsTracking] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [activity, setActivity] = useState('');

  useEffect(() => {
    let interval: number | undefined;
    if (isTracking) {
      interval = window.setInterval(() => {
        setElapsedTime((prevTime) => prevTime + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTracking]);

  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleStartStop = () => {
    setIsTracking(!isTracking);
  };

  const handleReset = () => {
    setIsTracking(false);
    setElapsedTime(0);
    setActivity('');
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Time Tracking</h1>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="mb-4">
          <input
            type="text"
            placeholder="What are you working on?"
            className="w-full p-2 border rounded"
            value={activity}
            onChange={(e) => setActivity(e.target.value)}
          />
        </div>
        <div className="text-6xl font-bold mb-4 text-center">
          {formatTime(elapsedTime)}
        </div>
        <div className="flex justify-center space-x-4">
          <button
            className={`p-2 rounded-full ${isTracking ? 'bg-red-500' : 'bg-green-500'} text-white`}
            onClick={handleStartStop}
          >
            {isTracking ? <Pause size={24} /> : <Play size={24} />}
          </button>
          <button
            className="p-2 rounded-full bg-gray-300 text-gray-700"
            onClick={handleReset}
          >
            <RotateCcw size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default TimeTracking;